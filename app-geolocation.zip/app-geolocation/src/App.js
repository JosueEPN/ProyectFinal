import React from 'react';
import Signin from './pages/login/Signin';
import Signup from './pages/register/Signup';
import { Route, Routes } from 'react-router-dom';
import { AuthContextProvider } from './context/AuthContext';
import ProtectedRoute from './utils/ProtectedRoute';
import Home from './pages/home/Home';
import Layout from './components/layout/Layout'
import Team from './pages/team/Team';
import Profile from './pages/profile/Profile';

function App() {
 
  return (
    <div>
      <AuthContextProvider>
        <Layout>
          <Routes>
            <Route path="/" element={<Signin />} />
            <Route path="/register" element={<Signup />} />
            <Route
              path="/home"
              element={
                <ProtectedRoute>
                  <Home />
                </ProtectedRoute>
              }
            />
            <Route
              path="/team"
              element={
                <ProtectedRoute>
                  <Team />
                </ProtectedRoute>
              }
            />
            <Route
              path="/my-profile"
              element={
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              }
            />
          </Routes>
        </Layout>
      </AuthContextProvider>
    </div>
  );
}

export default App;
