import { Box } from "@mui/material";
import React from "react";
//import { UserAuth } from "../../context/AuthContext";
import LayoutBodySignIn from "../../components/layout/LayoutBodySignIn";

const Home = () => {
  //const { user, logout } = UserAuth();

  return (
    <LayoutBodySignIn>
      <Box sx={{ backgroundColor: "red" }}>
        
      </Box>
    </LayoutBodySignIn>
  );
};

export default Home;
