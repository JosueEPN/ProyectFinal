import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import FormInput from "../../components/form/FormInput";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import GoogleIcon from "@mui/icons-material/Google";
import Typography from "@mui/material/Typography";
import { UserAuth } from '../../context/AuthContext';
import { ButtonGroup } from '@mui/material';

const Signin = () => {
  const [user, setUser] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { signIn, loginGoogle } = UserAuth();

  const inputs = [
    {
      id: 1,
      name: "email",
      type: "email",
      placeholder: "example@empresa.com",
      errorMessage: "It should be a valid email address!",
      label: "Email",
      required: true,
    },
    {
      id: 2,
      name: "password",
      type: "password",
      placeholder: "Ingresa tu contraseña",
      errorMessage:
        "Password should be 8-20 characters and include at least 1 letter, 1 number and 1 special character!",
      label: "Password",
      required: true,
    },
  ];
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await signIn(user.email, user.password);
      navigate("/home");
      console.log("usuario logueado", user);
    } catch (error) {
      console.log(error);
      if (error.code === "auth/user-not-found") {
        setError("No existe el usuario");
      }
      if (error.code === "auth/wrong-password") {
        setError("Clave inválida");
      }
    }
  };
  const handleGoogleSignIn = async () => {
    try {
      await loginGoogle()
      navigate("/home")
      
    } catch (error) {
      setError(error.message)
    }
  };
  const onChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  return (
    <>
      <div>{error && <p>{error}</p>}</div>

      <Card
        style={{
          maxWidth: 450,
          padding: "20px 5px",
          margin: "0 auto",
        }}
      >
        <CardContent
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <p>Inicia Sesión</p>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={1}>
              {inputs.map((input) => (
                <FormInput
                  key={input.id}
                  {...input}
                  value={user[input.name]}
                  onChange={onChange}
                />
              ))}
              <Grid item xs={12} sx={{ padding: "15px" }}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  fullWidth
                >
                  Iniciar sesión
                </Button>
              </Grid>
            </Grid>
          </form>
          <div>
            <ButtonGroup onClick={handleGoogleSignIn}>
              <Button sx={{ width: "100px" }}>
                <GoogleIcon />
              </Button>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
              >
                Iniciar sesión con Google
              </Button>
            </ButtonGroup>
          </div>
          <Grid>
            <Typography variant="h6" gutterBottom component="div">
              ¿No tienes cuenta?
              <Link to="/register">Regístrate</Link>
            </Typography>
          </Grid>
        </CardContent>
      </Card>
    </>
  );
};

export default Signin;
