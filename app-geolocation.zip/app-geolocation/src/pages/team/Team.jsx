import React, { useState } from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import FormControl from "@mui/material/FormControl";
import LayoutBodySignIn from "../../components/layout/LayoutBodySignIn";
import Add from "../../components/add/Add";

const Team = () => {
  const [user, setUser] = useState({
    categoría: "",
  });
  
  const handleSubmit = async (e) => {
    e.preventDefault();
  };
  const onChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };
  console.log("userteam", user)

  return (
    <LayoutBodySignIn>
      <Card style={{ maxWidth: 450, padding: "20px 5px", margin: "0 auto" }}>
        <CardContent>
          <p>Únete a un equipo de deporte</p>
          <form onSubmit={handleSubmit}>
            <Grid item xs={12}>
              <FormControl>
                <label>Equipos</label>
                <Select
                  labelId="categoria"
                  name="categoria" /*misma propiedad q en el inputs y se guarda en el estado */
                  value={user.categoría}
                  label="Categoria"
                  onChange={onChange}
                >
                  <MenuItem value="natacion">Natación</MenuItem>
                  <MenuItem value="ciclismo">Ciclismo</MenuItem>
                  <MenuItem value="running">Running</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
              >
                Guardar
              </Button>
            </Grid>
          </form>
        </CardContent>
      </Card>
      <div>
        <Add />
        <h1>siuuuuuuu</h1>
      </div>
    </LayoutBodySignIn>
  );
};

export default Team;
