import React from 'react'
import LayoutBodySignIn from "../../components/layout/LayoutBodySignIn";


const Profile = () => {
  return (
    <LayoutBodySignIn>
      Mi perfil
    </LayoutBodySignIn>
  );
}

export default Profile