import {
  Box,
  ImageList,
  ImageListItem,
  Typography,
} from "@mui/material";
import React from "react";

const Rightbar = () => {
  const imagesData = [
    {
      id: 1,
      src: "https://material-ui.com/static/images/image-list/breakfast.jpg",
      alt: "1",
    },
    {
      id: 2,
      src: "https://material-ui.com/static/images/image-list/breakfast.jpg",
      alt: "1",
    },
    {
      id: 3,
      src: "https://material-ui.com/static/images/image-list/breakfast.jpg",
      alt: "1",
    },
    {
      id: 4,
      src: "https://material-ui.com/static/images/image-list/breakfast.jpg",
      alt: "1",
    },
    {
      id: 5,
      src: "https://material-ui.com/static/images/image-list/breakfast.jpg",
      alt: "1",
    },
  ];

  return (
    <Box flex={2} p={2} sx={{ display: { xs: "none", sm: "block" } }}>
      <Box position="fixed" width={300}>
        <Typography variant="h6" fontWeight={100} mt={2} mb={2}>
          Lugares
        </Typography>
        <ImageList cols={3} rowHeight={100} gap={5}>
          {
            imagesData.map(image => (
              <ImageListItem key={image.id}>
                <img
                  src={image.src}
                  alt={image.alt}
                />
              </ImageListItem>
            ))
          }
        </ImageList>
      </Box>
    </Box>
  );
};

export default Rightbar;
