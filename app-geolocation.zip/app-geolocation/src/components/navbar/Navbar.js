import React, { useState } from "react";
import {
  AppBar,
  Avatar,
  Box,
  InputBase,
  Menu,
  MenuItem,
  styled,
  Toolbar,
  Typography,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { UserAuth } from "../../context/AuthContext";

const StyledToolbar = styled(Toolbar)({
  display: "flex",
  justifyContent: "space-between",
});

const Search = styled("div")(({ theme }) => ({
  backgroundColor: "white",
  padding: "0 10px",
  borderRadius: theme.shape.borderRadius,
  width: "40%",
}));

const Icons = styled(Box)(({ theme }) => ({
  display: "none",
  alignItems: "center",
  gap: "20px",
  [theme.breakpoints.up("sm")]: {
    display: "flex",
  },
}));

const UserBox = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  gap: "10px",
  [theme.breakpoints.up("sm")]: {
    display: "none",
  },
}));

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const { user, logout } = UserAuth();
  const navigate = useNavigate();

  console.log("navbar, user logueado ", user)
  
  const handleLogout = async () => {
    try {
      await logout();
      navigate("/");
      console.log("Cerrie de sesión");
      setOpen(false)
    } catch (e) {
      console.log(e.message);
    }
  };

  return (
    <AppBar position="sticky">
      <StyledToolbar>
        <Typography variant="h6" sx={{ display: { xs: "none", sm: "block" } }}>
          UBÍCATE!!
        </Typography>
        
        <Icons onClick={() => setOpen(true)}>
          <Avatar
            sx={{ width: 30, height: 30 }}
            src="https://assets-es.imgfoot.com/zlatan-ibrahimovic-ac-milan-fm.jpg"
          />
          <Typography variant="span">
            {user ? user.displayName || user.email : <h3>:D</h3>}
          </Typography>
        </Icons>
        <UserBox onClick={() => setOpen(true)}>
          <Avatar
            sx={{ width: 30, height: 30 }}
            src="https://assets-es.imgfoot.com/zlatan-ibrahimovic-ac-milan-fm.jpg"
          />
          <Typography variant="span">
            {user ? user.displayName || user.email : <h3>:D</h3>}
          </Typography>
        </UserBox>
      </StyledToolbar>
      {/* ese "css" ubica debajo del perfil al logout */}
      <Menu
        id="demo-positioned-menu"
        aria-labelledby="demo-positioned-button"
        open={open}
        onClose={() => setOpen(false)}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
      >
        {user ? (
          <MenuItem onClick={handleLogout}>Logout</MenuItem>
        ) : (
          <h3>Inicia sesión!!</h3>
        )}
      </Menu>
    </AppBar>
  );
};

export default Navbar;