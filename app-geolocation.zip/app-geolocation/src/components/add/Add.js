import {
  Button,
  ButtonGroup,
  Fab,
  Modal,
  styled,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import { Add as AddIcon } from "@mui/icons-material";
import { Box } from "@mui/system";

const SytledModal = styled(Modal)({
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
});

const Add = () => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Tooltip
        onClick={(e) => setOpen(true)}
        title="Delete"
        sx={{
          position: "fixed",
          bottom: 20,
          left: { xs: "calc(50% - 25px)", md: 30 },
        }}
      >
        <Fab color="primary" aria-label="add">
          <AddIcon />
        </Fab>
      </Tooltip>
      <SytledModal
        open={open}
        onClose={(e) => setOpen(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box
          width={400}
          height={280}
          bgcolor={"#cfd8dc"}
          color={"text.primary"}
          p={3}
          borderRadius={5}
        >
          <Typography variant="h6" color="black" textAlign="center">
            Añadir usuario al grupo
          </Typography>
          <TextField
            sx={{ width: "100%", paddingTop: "30px" }}
            id="standard-multiline-static"
            multiline
            placeholder="Digita el email"
            variant="standard"
          />
          <Box sx={{ width: "100%", paddingTop: "80px" }}>
            <Button
              fullWidth
              variant="contained"
              aria-label="outlined primary button group"
            >
              Añadir Usuario
            </Button>
          </Box>
        </Box>
      </SytledModal>
    </>
  );
};

export default Add;
