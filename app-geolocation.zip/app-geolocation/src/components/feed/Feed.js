import { Box, Stack, Skeleton, Grid } from "@mui/material";
import React, { useState } from "react";

const Feed = ( {user, children} ) => {
  const [loading, setLoading] = useState(true);

  // setTimeout(() => {
  //   setLoading(false);
  // }, [3000]);

  return (
    <Box flex={4} p={{ xs: 0, md: 2 }}>
      <h3>Bienvenido a Ubícate!! {user.displayName || user.email}</h3>
      {loading ? (
        <>
          <>{children}</>
          <Grid container>
            <Grid item xs={2} md={2}>
              <Skeleton
                variant="circle"
                height={70}
                width={70}
                sx={{ borderRadius: "50%", border: 1 }}
              />
            </Grid>
            <Grid item xs={10} md={10}>
              <Stack spacing={1}>
                <Skeleton variant="text" height={20} width={100} />
                <Skeleton
                  variant="text"
                  height={100}
                  sx={{ paddingTop: "70px", border: 1 }}
                />
                <Skeleton variant="text" height={20} />
                <Skeleton variant="text" height={20} />
                <Skeleton
                  variant="rectangular"
                  height={300}
                  sx={{ borderRadius: "20px", border: 1 }}
                />
              </Stack>
            </Grid>
          </Grid>
          <Grid container sx={{ paddingTop: "35px" }}>
            <Grid item xs={2} md={2}>
              <Skeleton
                variant="circle"
                height={70}
                width={70}
                sx={{ borderRadius: "50%", border: 1 }}
              />
            </Grid>
            <Grid item xs={10} md={10}>
              <Stack spacing={1}>
                <Skeleton variant="text" height={20} width={100} />
                <Skeleton
                  variant="text"
                  height={100}
                  sx={{ paddingTop: "70px", border: 1 }}
                />
                <Skeleton variant="text" height={20} />
                <Skeleton variant="text" height={20} />
                <Skeleton
                  variant="rectangular"
                  height={300}
                  sx={{ borderRadius: "20px", border: 1 }}
                />
              </Stack>
            </Grid>
          </Grid>
        </>
      ) : (
        <>
          <h1>tu perfil</h1>
        </>
      )}
    </Box>
  );
};

export default Feed;
