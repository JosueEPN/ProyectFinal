import React from 'react'

const FeedRol = () => {
  return (
    <div>FeedRol</div>
  )
}

export default FeedRol