import { Typography } from '@mui/material';
import Box from '@mui/material/Box';

const Footer = () => {
  return (
    <Box
      display="flex"
      alignItems="center"
      justifyContent="center"
      sx={{ backgroundColor: "primary.dark", minHeight: "10vh" }}
    >
      <Typography variant="h6">@Copyright 2022 Ubícate xd</Typography>
    </Box>
  );
};

export default Footer;
