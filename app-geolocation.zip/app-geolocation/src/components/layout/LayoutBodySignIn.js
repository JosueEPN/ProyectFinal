import React from "react";
import { UserAuth } from "../../context/AuthContext";
import Sidebar from "../sidebar/Sidebar";
import Feed from "../feed/Feed";
import Rightbar from "../rightbar/Rightbar";
import { Stack } from "@mui/material";

const  LayoutBodySignIn = ({ children }) => {
  const { user } = UserAuth();

  return (
    <Stack direction="row" spacing={2} justifyContent="space-between">
      <Sidebar />
      <Feed user={user} children={children} />
      <Rightbar />
    </Stack>
  );
};

export default LayoutBodySignIn;
