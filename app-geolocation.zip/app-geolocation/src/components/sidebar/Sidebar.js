import { useNavigate, useLocation } from "react-router-dom";
import React from "react";
import { AccountBox, Group, Home, Person } from "@mui/icons-material";
import { Box, List, ListItem, ListItemIcon, ListItemText } from "@mui/material";
import styles from "./styles.module.css";

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    {
      text: "Home",
      icon: <Home color="secondary" />,
      path: "/home",
    },
    {
      text: "Mi Grupo",
      icon: <Group color="secondary" />,
      path: "/team",
    },
    {
      text: "Personas",
      icon: <Person color="secondary" />,
      path: "/people",
    },
    {
      text: "Perfil",
      icon: <AccountBox color="secondary" />,
      path: "/my-profile",
    },
  ];

  return (
    <Box flex={1} p={2} sx={{ display: { xs: "none", sm: "block" } }}>
      <Box>
        <List>
          {menuItems.map((item) => (
            <ListItem
              button
              key={item.text}
              onClick={() => navigate(item.path)}
              className={
                location.pathname === item.path ? styles.active : null
              }
            >
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItem>
          ))}
        </List>
      </Box>
    </Box>
  );
};

export default Sidebar;
