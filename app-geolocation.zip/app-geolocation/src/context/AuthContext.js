import { createContext, useContext, useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import { auth, app } from '../firebase';
import {
  getFirestore,
  doc,
  collection,
  setDoc,
  getDoc,
} from "firebase/firestore";

const UserContext = createContext();

export const AuthContextProvider = ({ children }) => {
  const [user, setUser] = useState({});
  const firestore = getFirestore(app);

  const createUser = async (email, password) => {
    const userData = await createUserWithEmailAndPassword(auth, email, password).then((userFirebase) => {
      return userFirebase;
    });
    const docPath = doc(firestore, `user/${userData.user.uid}`);
    setDoc(docPath, { correo: email,});
  };

   const signIn = async (email, password) =>  {
    const userData = await signInWithEmailAndPassword(auth, email, password).then((userFirebase) => {
      return userFirebase;
    });
    const docPath = doc(firestore, `user/${userData.user.uid}`);
    setDoc(docPath, { correo: email,});
   }

  const logout = () => {
      return signOut(auth)
  }

  const loginGoogle = () => {
    const googleProvider = new GoogleAuthProvider()
    return signInWithPopup(auth, googleProvider)
  }
  
  /**
   * cuando el estado de auth ha cambiado, -> si me logueo, me devuelve un user
   * si hago logout, me devuelve el estado
   * con el useeffect lo cargamos apenas inicia la app o sea apneas se llame a este 
   * authconextprovider
   */
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      console.log(currentUser);
      setUser(currentUser);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  return (
    <UserContext.Provider value={{ createUser, user, logout, signIn, loginGoogle }}>
      {children}
    </UserContext.Provider>
  );
};

export const UserAuth = () => {
  return useContext(UserContext);
};
