// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";


// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC_BsUxa4u4CJi4mJZlseMzKRDVuT5lbyk",
  authDomain: "project2login-4d62a.firebaseapp.com",
  projectId: "project2login-4d62a",
  storageBucket: "project2login-4d62a.appspot.com",
  messagingSenderId: "490530731124",
  appId: "1:490530731124:web:952732e3feabc24ddccd21",
  measurementId: "G-LWPCGVV006",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const storage = getStorage(app);



